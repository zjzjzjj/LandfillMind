import { lazy, Suspense, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Stethoscope, Calculator, MessageCircle, ArrowRight, Shield, Zap, BookOpen, HardHat, Printer, X } from 'lucide-react';
import type { NavigateFunction } from 'react-router-dom';
import type { DiagnosisResult } from '../types';
import { buildSafetyBrief } from '../utils/safetyBrief';
import { openPrintableHtml, exportEmergencyPosterHtml } from '../utils/exporter';
import { generateEmergencyPosterHtml, getDemoEmergencyData } from '../utils/emergencyPoster';
// 3D 场景约 500KB（three.js），懒加载避免拖慢首页首屏
const LandfillScene3D = lazy(() => import('../components/LandfillScene3D'));

// 入口动画 stagger
const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.08 } },
};
const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] } },
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  desc: string;
  badge?: string;
  onClick: () => void;
}

function FeatureCard({ icon, title, desc, badge, onClick }: FeatureCardProps) {
  return (
    <motion.button
      variants={itemVariants}
      onClick={onClick}
      className="group relative w-full text-left rounded-2xl p-5 border transition-all duration-200"
      style={{
        backgroundColor: 'var(--bg-surface)',
        borderColor: 'var(--border)',
      }}
      whileHover={{
        y: -3,
        borderColor: 'var(--border-accent)',
        boxShadow: '0 8px 30px rgba(0,0,0,0.2)',
      }}
    >
      {/* 图标区 */}
      <div
        className="w-10 h-10 rounded-xl flex items-center justify-center mb-3 transition-transform duration-200 group-hover:scale-110"
        style={{ backgroundColor: 'var(--primary-glow)' }}
      >
        <span style={{ color: 'var(--primary)' }}>{icon}</span>
      </div>
      {/* 标题行 */}
      <div className="flex items-center gap-2 mb-1.5">
        <h3 className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{title}</h3>
        {badge && (
          <span className="text-[10px] px-1.5 py-0.5 rounded-full font-medium"
                style={{ backgroundColor: 'var(--primary-glow)', color: 'var(--primary)' }}>
            {badge}
          </span>
        )}
      </div>
      <p className="text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{desc}</p>
      {/* 箭头 */}
      <div className="absolute top-5 right-5 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
           style={{ color: 'var(--text-muted)' }}>
        <ArrowRight size={14} />
      </div>
    </motion.button>
  );
}

interface StatCardProps {
  label: string;
  value: string;
  unit?: string;
  trend?: 'up' | 'down' | 'stable';
  color: string;
}

function StatCard({ label, value, unit, color }: StatCardProps) {
  return (
    <motion.div variants={itemVariants}
      className="relative rounded-2xl p-4 border overflow-hidden"
      style={{ backgroundColor: 'var(--bg-surface)', borderColor: 'var(--border)' }}
    >
      {/* 顶部色条 */}
      <div className="absolute top-0 left-0 right-0 h-0.5 rounded-t-2xl" style={{ backgroundColor: color }} />
      <p className="text-[11px] font-medium mb-2" style={{ color: 'var(--text-muted)' }}>{label}</p>
      <div className="flex items-end gap-1">
        <span className="text-2xl font-bold font-mono" style={{ color }}>{value}</span>
        {unit && <span className="text-xs mb-0.5" style={{ color: 'var(--text-muted)' }}>{unit}</span>}
      </div>
    </motion.div>
  );
}

interface HomePageProps {
  onNavigate: NavigateFunction;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  const navigate = useNavigate();

  // 一键带入对话：写 sessionStorage，ChatPage 挂载后自动发送
  const startChatWith = (question: string) => {
    sessionStorage.setItem('chat-prefill', question);
    navigate('/chat/new');
  };

  // 现场一键应急模式（差异化创新功能·想法 5）：3 秒拿到一张完整决策包 PDF
  // - 弹出全屏预览 modal
  // - 提供"🖨 一键打印"调用浏览器原生打印 / 另存为 PDF
  // - 同时提供"📤 在新标签页打开"（适合发微信群 / 张贴 QR 海报）
  const [emergencyOpen, setEmergencyOpen] = useState(false);
  const [emergencyData] = useState(() => getDemoEmergencyData());
  const emergencyHtml = emergencyOpen
    ? generateEmergencyPosterHtml(emergencyData.diagnosis, emergencyData.siteName)
    : '';
  const openEmergency = () => setEmergencyOpen(true);
  const closeEmergency = () => setEmergencyOpen(false);
  // 新标签页打开完整决策包（适合微信群发、海报打印机）
  const openEmergencyInNewTab = () => {
    void exportEmergencyPosterHtml(emergencyData.diagnosis, emergencyData.siteName);
  };

  // 首页"今日班前交底卡"默认示例：未完成诊断时也能让评委一眼看到工友视角
  // 使用最常见的边坡+渗滤液组合（演示场地 LF-01），保持 buildSafetyBrief 纯确定性路径
  const handlePrintBrief = () => {
    const demoResult: DiagnosisResult = {
      overallRisk: 'orange',
      risks: [
        {
          id: 'demo-slope', category: '边坡', title: '填埋场整体稳定',
          description: '示范场地 Fs ≈ 1.18，低于 CJJ 176 运行期要求 ≥ 1.30，存在滑坡/失稳隐患。',
          level: 'orange', value: 'Fs ≈ 1.18', unit: '', threshold: 'Fs ≥ 1.30',
          suggestion: '降低渗滤液水位、加密位移监测、必要时进行稳定化加固（放缓坡比 / 减重 / 注浆）。',
        },
        {
          id: 'demo-leachate', category: '渗滤液', title: '渗滤液液位偏高',
          description: '示范场地液位埋深仅 1.2m，抬高孔隙水压力并易引发渗漏。',
          level: 'orange', value: '水位埋深≈1.2 m', unit: '', threshold: '≥ 1.5 m',
          suggestion: '提升抽排能力、疏通导排盲沟，雨前加密巡查。',
        },
      ],
      report: {
        overview: '示范场地 LF-01 综合风险等级：较大风险（橙色）。主要隐患：边坡 Fs 偏低、渗滤液液位偏高。建议班前重点交底：边坡警戒与下井作业安全。',
        sections: [],
        regulations: ['CJJ 176-2012', 'GB 16889-2008'],
        actions: {
          immediate: ['班前测气：CH₄、H₂S 双报警仪', '雨后先巡查裂缝再作业'],
          shortTerm: [],
          longTerm: [],
        },
        monitoring: ['边坡位移监测每日一次', '渗滤液液位每 4 小时记录'],
        conclusion: '示范场地当前为较大风险，请班组完成今日交底卡后签字再上岗。',
      },
    };
    openPrintableHtml('今日班前安全交底卡', buildSafetyBrief(demoResult, '示范场地 LF-01'));
  };

  return (
    <div className="flex-1 overflow-y-auto app-bg">
      {/* ===== Hero Section ===== */}
      <section
        className="relative min-h-[560px] flex items-center overflow-hidden hero-gradient"
      >
        {/* 浮动光斑：增加纵深 */}
        <div className="hero-blob" style={{ width: 440, height: 440, background: 'rgba(124,58,237,0.55)', top: -140, right: -90 }} />
        <div className="hero-blob" style={{ width: 380, height: 380, background: 'rgba(14,165,183,0.55)', bottom: -130, left: -70, animationDelay: '2.5s' }} />
        {/* 网格点阵背景（白色弱化） */}
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.6) 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
        {/* 底部柔化过渡到浅色页面 */}
        <div className="absolute inset-x-0 bottom-0 h-36" style={{ background: 'linear-gradient(to top, var(--bg-base), transparent)' }} />

        <div className="relative z-10 max-w-6xl mx-auto px-6 py-16 w-full">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="max-w-2xl"
          >

            {/* 主标题 */}
            <motion.h1 variants={itemVariants} className="mb-4 leading-tight" style={{ color: '#ffffff', textShadow: '0 2px 24px rgba(0,0,0,0.25)' }}>
              <span className="block text-4xl md:text-5xl font-bold tracking-tight">
                填埋场智慧监测系统
              </span>
              <span
                className="block text-lg md:text-xl font-normal mt-2"
                style={{ color: 'rgba(255,255,255,0.88)' }}
              >
                守护填埋场安全最后一公里
              </span>
            </motion.h1>

            {/* 副标题 */}
            <motion.p variants={itemVariants}
              className="text-sm leading-relaxed mb-8 max-w-xl"
              style={{ color: 'rgba(255,255,255,0.82)' }}
            >
              基于多智能体协同推理的填埋场/地下水污染场地 AI 诊断系统。
              输入场地监测数据，输出风险等级、规范依据与处置建议——
              让工程判断更高效，让安全底线更可靠。
            </motion.p>

            {/* CTA 按钮组 */}
            <motion.div variants={itemVariants} className="flex flex-wrap gap-3">
              <motion.button
                onClick={() => navigate('/diagnose')}
                className="btn-gradient inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-white transition-all duration-200"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
              >
                <Stethoscope size={15} />
                开始 AI 快诊
              </motion.button>
              <motion.button
                onClick={() => navigate('/chat/new')}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium border transition-all duration-200"
                style={{ borderColor: 'rgba(255,255,255,0.4)', color: '#ffffff', backgroundColor: 'rgba(255,255,255,0.12)' }}
                whileHover={{ backgroundColor: 'rgba(255,255,255,0.22)', borderColor: 'rgba(255,255,255,0.6)' }}
                whileTap={{ scale: 0.97 }}
              >
                <MessageCircle size={15} />
                专家问答
              </motion.button>
              <motion.button
                onClick={() => navigate('/design')}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium border transition-all duration-200"
                style={{ borderColor: 'rgba(255,255,255,0.4)', color: '#ffffff', backgroundColor: 'rgba(255,255,255,0.12)' }}
                whileHover={{ backgroundColor: 'rgba(255,255,255,0.22)', borderColor: 'rgba(255,255,255,0.6)' }}
                whileTap={{ scale: 0.97 }}
              >
                <Calculator size={15} />
                查看计算中心
              </motion.button>
            </motion.div>
          </motion.div>

        </div>

        {/* 底部过渡由 hero-gradient + 柔化层处理 */}
      </section>

      {/* ===== 数据看板 ===== */}
      <section className="max-w-6xl mx-auto px-6 pt-10 pb-8">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-50px' }}
        >
          <motion.div variants={itemVariants} className="mb-5">
            <h2 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>
              诊断指标总览
            </h2>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
              系统内置 5 大风险维度，覆盖填埋场全生命周期关键参数
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <StatCard label="边坡稳定系数" value="1.35" unit="Fs" color="#10b981" />
            <StatCard label="渗滤液液位" value="0.8" unit="m" color="#3b82f6" />
            <StatCard label="CH₄ 浓度" value="3.2" unit="%" color="#f59e0b" />
            <StatCard label="地下水位" value="12.5" unit="m" color="#06b6d4" />
            <StatCard label="综合风险" value="低" color="#10b981" />
          </div>
        </motion.div>
      </section>

      {/* ===== 三维场地模型 ===== */}
      <section className="max-w-6xl mx-auto px-6 pb-12">
        <div className="flex items-end justify-between flex-wrap gap-3 mb-5">
          <div>
            <h2 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>
              三维场地模型
            </h2>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
              山谷型生活垃圾卫生填埋场全要素三维示意：地形、堆体、防渗、渗滤液、填埋气、截洪沟与生产辅助设施
            </p>
          </div>
          <span
            className="text-[10px] px-2.5 py-1 rounded-full font-medium"
            style={{ backgroundColor: 'var(--primary-glow)', color: 'var(--primary)' }}
          >
            交互式 · 可剖切 · 可透视
          </span>
        </div>
        <div
          className="rounded-2xl border overflow-hidden relative"
          style={{ borderColor: 'var(--border)', backgroundColor: 'var(--bg-surface)', boxShadow: '0 12px 40px rgba(8,47,73,0.08)' }}
        >
          <Suspense fallback={
            <div className="h-[560px] flex items-center justify-center" style={{ backgroundColor: 'var(--bg-base)' }}>
              <div className="text-center">
                <div className="w-8 h-8 border-[3px] rounded-full mx-auto mb-2 animate-spin"
                     style={{ borderColor: 'var(--border)', borderTopColor: 'var(--primary)' }} />
                <p className="text-xs" style={{ color: 'var(--text-muted)' }}>三维场景加载中…</p>
              </div>
            </div>
          }>
            <LandfillScene3D height={560} />
          </Suspense>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {['防渗衬层', '渗滤液导排', '填埋气火炬', '环场截洪沟', '垃圾坝', '监测井'].map((t) => (
            <span
              key={t}
              className="text-[10px] px-2 py-1 rounded-full"
              style={{ backgroundColor: 'var(--bg-elevated)', color: 'var(--text-secondary)' }}
            >
              {t}
            </span>
          ))}
          <span className="text-[10px] ml-auto" style={{ color: 'var(--text-muted)' }}>
            提示：左侧面板可切换图层、开启剖切/透视，悬停构件查看说明，点击防渗层 / 覆盖查看结构详图
          </span>
        </div>
      </section>

      {/* ===== 功能入口 ===== */}
      <section className="max-w-6xl mx-auto px-6 pb-10">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-50px' }}
        >
          <motion.div variants={itemVariants} className="mb-5">
            <h2 className="text-lg font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>
              核心功能
            </h2>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
              三大模块协同，覆盖填埋场诊断、设计与咨询全流程
            </p>
          </motion.div>

          <motion.div variants={containerVariants} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <FeatureCard
              icon={<Stethoscope size={20} />}
              title="AI 快诊"
              desc="输入场地监测数据，双引擎智能识别边坡/渗滤液/填埋气/地下水隐患，输出红橙黄蓝四级风险报告。"
              badge="核心"
              onClick={() => navigate('/diagnose')}
            />
            <FeatureCard
              icon={<Calculator size={20} />}
              title="计算中心"
              desc="12 项专业工程计算器：Fs 稳定系数、渗滤液产量 HELP、LandGEM 产气量、沉降预测、库容年限……带规范引用。"
              onClick={() => navigate('/design')}
            />
            <FeatureCard
              icon={<MessageCircle size={20} />}
              title="专家问答"
              desc="基于 50 条规范 KB 的智能对话，知识库检索增强 + 工程计算内核全程可视化，引用规范带版本年号。"
              onClick={() => navigate('/chat/new')}
            />
          </motion.div>
        </motion.div>
      </section>

      {/* ===== 为工友谋幸福 · 工友安全 ===== */}
      <section className="max-w-6xl mx-auto px-6 pb-10">
        <div className="rounded-2xl border p-5" style={{ borderColor: 'var(--border)', backgroundColor: 'var(--bg-surface)' }}>
          <div className="flex items-center gap-2 mb-1">
            <HardHat size={16} style={{ color: '#f59e0b' }} />
            <h2 className="text-lg font-semibold" style={{ color: 'var(--text-primary)' }}>为工友谋幸福 · 工友安全</h2>
          </div>
          <p className="text-xs mb-4" style={{ color: 'var(--text-muted)' }}>
            污染场地修复的每一道工序背后都是一线工友。把规范条文翻译成工友听得懂的安全须知，把应急能力落到班组。
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <button
              onClick={handlePrintBrief}
              className="group text-left rounded-xl border p-4 transition-all duration-200 hover:-translate-y-0.5"
              style={{ borderColor: 'var(--border)', backgroundColor: 'var(--bg-elevated)' }}
            >
              <div className="flex items-center gap-2 mb-1.5">
                <Printer size={14} style={{ color: '#f59e0b' }} />
                <span className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>📋 生成今日班前交底卡（打印）</span>
                <ArrowRight size={12} className="ml-auto transition-transform group-hover:translate-x-0.5" style={{ color: 'var(--text-muted)' }} />
              </div>
              <p className="text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                把 AI 快诊里的红/橙风险自动翻译成工友听得懂的交底卡，一键打印或导出 PDF，班组签字即可上岗。
              </p>
            </button>
            <button
              onClick={() => startChatWith('我是填埋场班组安全员，工友上岗前我要确认哪些防护要点？边坡警戒、下井测气、H₂S/CH₄ 防护、应急疏散？')}
              className="group text-left rounded-xl border p-4 transition-all duration-200 hover:-translate-y-0.5"
              style={{ borderColor: 'var(--border)', backgroundColor: 'var(--bg-elevated)' }}
            >
              <div className="flex items-center gap-2 mb-1.5">
                <Shield size={14} style={{ color: '#10b981' }} />
                <span className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>🛡 咨询安全专家</span>
                <ArrowRight size={12} className="ml-auto transition-transform group-hover:translate-x-0.5" style={{ color: 'var(--text-muted)' }} />
              </div>
              <p className="text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                跳转 AI 助手，进一步咨询 H₂S/CH₄ 防护、有限空间作业、应急疏散与三级响应等问题。
              </p>
            </button>
          </div>
          {/* ===== ⚡ 现场一键应急模式（差异化创新·想法 5） ===== */}
          <motion.button
            onClick={openEmergency}
            whileHover={{ scale: 1.01, y: -1 }}
            whileTap={{ scale: 0.99 }}
            className="mt-3 w-full text-left rounded-xl p-4 flex items-center gap-4 transition-shadow duration-200"
            style={{
              background: 'linear-gradient(135deg, #b91c1c 0%, #ea580c 60%, #f59e0b 100%)',
              color: '#fff',
              boxShadow: '0 10px 30px rgba(185,28,28,0.35)',
              border: '1px solid rgba(255,255,255,0.18)',
            }}
          >
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: 'rgba(255,255,255,0.18)', boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.25)' }}
            >
              <Zap size={22} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-base font-bold tracking-wide">⚡ 现场一键应急模式（3 秒拿到决策包）</span>
                <span
                  className="text-[10px] px-1.5 py-0.5 rounded-full font-bold"
                  style={{ backgroundColor: 'rgba(255,255,255,0.25)', color: '#fff' }}
                >
                  NEW
                </span>
              </div>
              <p className="text-xs leading-relaxed" style={{ color: 'rgba(255,255,255,0.92)' }}>
                一键合并：诊断报告摘要 + 班前安全交底卡 + 风险矩阵（4×4）+ 应急疏散路线 + 现场 QR 海报
                → 一张 A4 海报，可直接打印 / 微信群发 / 张贴。
              </p>
            </div>
            <ArrowRight size={18} className="flex-shrink-0" style={{ color: '#fff' }} />
          </motion.button>
        </div>
      </section>

      {/* ===== ⚡ 现场应急决策包 全屏预览 modal ===== */}
      <AnimatePresence>
        {emergencyOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ backgroundColor: 'rgba(2,6,23,0.78)', backdropFilter: 'blur(6px)' }}
            onClick={closeEmergency}
          >
            <motion.div
              initial={{ scale: 0.96, y: 12 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.96, y: 12 }}
              transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
              className="relative w-full max-w-5xl h-[92vh] rounded-2xl overflow-hidden flex flex-col"
              style={{ backgroundColor: 'var(--bg-base)', border: '1px solid var(--border)', boxShadow: '0 30px 80px rgba(0,0,0,0.5)' }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* modal 顶部条 */}
              <div
                className="flex items-center gap-3 px-5 py-3 border-b"
                style={{ backgroundColor: 'var(--bg-surface)', borderColor: 'var(--border)' }}
              >
                <div
                  className="w-9 h-9 rounded-lg flex items-center justify-center"
                  style={{ background: 'linear-gradient(135deg, #b91c1c, #f59e0b)', color: '#fff' }}
                >
                  <Zap size={18} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
                    ⚡ 现场应急决策包预览 · {emergencyData.siteName}
                  </div>
                  <div className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
                    诊断摘要 + 班前交底卡 + 风险矩阵 + 疏散路线 + QR 海报 · 一张 A4 即可打印
                  </div>
                </div>
                <button
                  onClick={openEmergencyInNewTab}
                  className="text-xs px-3 py-1.5 rounded-lg border transition-colors duration-150"
                  style={{ borderColor: 'var(--border)', color: 'var(--text-secondary)', backgroundColor: 'var(--bg-elevated)' }}
                  title="在新标签页打开完整决策包，方便微信群发 / 打印机调用"
                >
                  📤 新标签页打开
                </button>
                <button
                  onClick={() => {
                    // 直接调用预览 iframe 的 window.print，绕过 Blob URL
                    const iframe = document.getElementById('emergency-preview-iframe') as HTMLIFrameElement | null;
                    if (iframe && iframe.contentWindow) iframe.contentWindow.print();
                  }}
                  className="text-xs px-3 py-1.5 rounded-lg font-semibold text-white"
                  style={{ background: 'linear-gradient(135deg, #b91c1c, #ea580c)' }}
                >
                  🖨 一键打印
                </button>
                <button
                  onClick={closeEmergency}
                  aria-label="关闭"
                  className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors duration-150"
                  style={{ backgroundColor: 'var(--bg-elevated)', color: 'var(--text-secondary)' }}
                >
                  <X size={16} />
                </button>
              </div>
              {/* iframe 预览：把完整 HTML 灌进 srcDoc，避免弹窗拦截 */}
              <div className="flex-1 overflow-hidden" style={{ backgroundColor: '#0f172a' }}>
                <iframe
                  id="emergency-preview-iframe"
                  title="现场应急决策包预览"
                  srcDoc={emergencyHtml}
                  className="w-full h-full border-0"
                  style={{ backgroundColor: '#fff' }}
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== 规范依据 ===== */}
      <section
        className="border-t"
        style={{ borderColor: 'var(--border)', backgroundColor: 'var(--bg-surface)' }}
      >
        <div className="max-w-6xl mx-auto px-6 py-8">
          <div className="flex items-center gap-2 mb-5">
            <BookOpen size={16} style={{ color: 'var(--primary)' }} />
            <h3 className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
              规范依据
            </h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {[
              'GB 16889-2008', 'CJJ 176-2012', 'HJ 25.1~25.6', 'GB 36600-2018',
              'GB/T 14848-2017', 'HJ 1139-2020', 'GB 55038-2025', 'AQ 4202-2009',
            ].map(std => (
              <span
                key={std}
                className="px-3 py-1.5 rounded-full text-xs font-mono border transition-colors duration-150"
                style={{
                  borderColor: 'var(--border)',
                  color: 'var(--text-secondary)',
                  backgroundColor: 'var(--bg-elevated)',
                }}
              >
                {std}
              </span>
            ))}
          </div>
          <p className="text-xs mt-4" style={{ color: 'var(--text-muted)' }}>
            共覆盖 30+ 本国家/行业标准，每条 KB 带规范编号、版本年号、条款摘要
          </p>
        </div>
      </section>

      {/* ===== 页脚 ===== */}
      <footer className="border-t text-center py-5" style={{ borderColor: 'var(--border)' }}>
        <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
          填埋场智慧监测系统 v4.0 · 基于 CodeBuddy Agent SDK · 第一届"海之子"杯 AI 智能体挑战计划参赛作品
        </p>
      </footer>
    </div>
  );
}
