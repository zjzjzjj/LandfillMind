import { useState, useRef } from 'react';
import { Plus, Settings, Stethoscope, Calculator, MessageCircle, BrainCircuit, X, Boxes } from 'lucide-react';
import type { Agent, Session } from '../types';

interface SidebarProps { sessions: Session[]; currentSessionId: string | null; isSettingsPage: boolean; isDiagnosePage: boolean; isDesignPage: boolean; isMultiAgentPage: boolean; isSimulatorPage: boolean; sidebarOpen: boolean; agents: Agent[]; getAgent: (id: string) => Agent | undefined; onNewChat: () => void; onSelectSession: (sessionId: string) => void; onDeleteSession: (sessionId: string) => void; onOpenSettings: () => void; onOpenDiagnose: () => void; onOpenDesign: () => void; onOpenMultiAgent: () => void; onOpenSimulator: () => void; }
interface NavItemProps { icon: React.ReactNode; label: string; active: boolean; onClick: () => void; badge?: string; }

function NavItem({ icon, label, active, onClick, badge }: NavItemProps) {
  return (
    <button onClick={onClick} title={label} className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-200 group relative" style={{ backgroundColor: active ? 'rgba(0,240,255,0.08)' : 'transparent', color: active ? 'var(--primary)' : 'var(--text-secondary)', boxShadow: active ? '0 0 12px rgba(0,240,255,0.08)' : 'none' }} onMouseEnter={e => { if (!active) { e.currentTarget.style.backgroundColor = 'rgba(0,240,255,0.04)'; e.currentTarget.style.color = 'var(--primary)'; } }} onMouseLeave={e => { if (!active) { e.currentTarget.style.backgroundColor = 'transparent'; e.currentTarget.style.color = 'var(--text-secondary)'; } }}>
      {active && <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 rounded-full" style={{ backgroundColor: 'var(--primary)', boxShadow: '0 0 8px var(--primary)' }} />}
      <span className="shrink-0 transition-transform duration-200 group-hover:scale-110">{icon}</span>
      <span className="flex-1 text-left font-medium truncate">{label}</span>
      {badge && <span className="text-[10px] px-1.5 py-0.5 rounded-full" style={{ backgroundColor: 'rgba(0,240,255,0.06)', color: 'var(--primary)', border: '1px solid rgba(0,240,255,0.15)' }}>{badge}</span>}
    </button>
  );
}

function SessionItem({ session, isActive, onSelect, onDelete }: { session: Session; isActive: boolean; onSelect: () => void; onDelete: () => void; }) {
  const [hover, setHover] = useState(false);
  return (
    <div className="group flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-all duration-200" style={{ backgroundColor: isActive ? 'rgba(0,240,255,0.08)' : hover ? 'rgba(0,240,255,0.03)' : 'transparent', borderLeft: isActive ? '2px solid var(--primary)' : '2px solid transparent', boxShadow: isActive ? '0 0 8px rgba(0,240,255,0.06)' : 'none' }} onClick={onSelect} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}>
      <span className="w-1.5 h-1.5 rounded-full shrink-0 transition-all duration-200" style={{ backgroundColor: isActive ? 'var(--primary)' : 'var(--text-muted)', boxShadow: isActive ? '0 0 6px var(--primary)' : 'none' }} />
      <span className="flex-1 text-xs truncate" style={{ color: isActive ? 'var(--text-primary)' : 'var(--text-secondary)' }}>{session.title}</span>
      {hover && <button onClick={e => { e.stopPropagation(); onDelete(); }} className="p-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: 'var(--text-muted)' }} onMouseEnter={e => (e.currentTarget.style.color = '#ff2d7b')} onMouseLeave={e => (e.currentTarget.style.color = 'var(--text-muted)')}><X size={12} /></button>}
    </div>
  );
}

export function Sidebar({ sessions, currentSessionId, isSettingsPage, isDiagnosePage, isDesignPage, isMultiAgentPage, isSimulatorPage, sidebarOpen, agents, onNewChat, onSelectSession, onDeleteSession, onOpenSettings, onOpenDiagnose, onOpenDesign, onOpenMultiAgent, onOpenSimulator }: SidebarProps) {
  const [chatHover, setChatHover] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  if (!sidebarOpen) return null;

  return (
    <aside className="flex flex-col flex-shrink-0 overflow-hidden relative" style={{ width: 'var(--sidebar-width)', backgroundColor: 'rgba(13,21,37,0.9)', backdropFilter: 'blur(16px)', borderRight: '1px solid var(--border)' }}>
      <div className="absolute top-0 right-0 w-[1px] h-full overflow-hidden pointer-events-none"><div className="absolute inset-x-0 h-1/4" style={{ background: 'linear-gradient(180deg, transparent, rgba(0,240,255,0.15), transparent)', animation: 'scan-sweep 4s ease-in-out infinite' }} /></div>
      <div className="flex items-center gap-2.5 px-4 shrink-0" style={{ height: 'var(--header-height)', borderBottom: '1px solid var(--border)' }}>
        <div className="w-7 h-7 rounded-lg flex items-center justify-center font-black text-sm shrink-0" style={{ background: 'linear-gradient(135deg, #00f0ff, #b44aff)', color: '#060a13', boxShadow: '0 0 12px rgba(0,240,255,0.3)' }}>智</div>
        <div className="flex flex-col min-w-0">
          <span className="text-sm font-semibold leading-tight truncate" style={{ color: 'var(--text-primary)' }}>填埋场智慧监测</span>
          <span className="text-[10px] leading-tight font-mono" style={{ color: 'var(--primary)', opacity: 0.6 }}>Smart Monitor v4.1</span>
        </div>
      </div>
      <div className="px-2 pt-3 pb-2 shrink-0">
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] px-3 mb-2" style={{ color: 'var(--text-muted)' }}>功能</p>
        <nav className="space-y-0.5">
          <NavItem icon={<Stethoscope size={15} />} label="AI 快诊" active={isDiagnosePage} onClick={onOpenDiagnose} />
          <NavItem icon={<Calculator size={15} />} label="计算中心" active={isDesignPage} onClick={onOpenDesign} />
          <NavItem icon={<Boxes size={15} />} label="3D 模拟" active={isSimulatorPage} onClick={onOpenSimulator} />
          <NavItem icon={<BrainCircuit size={15} />} label="多智能体" active={isMultiAgentPage} onClick={onOpenMultiAgent} />
          <NavItem icon={<MessageCircle size={15} />} label="专家问答" active={false} onClick={onNewChat} />
        </nav>
      </div>
      <div className="mx-3 h-[1px] relative overflow-hidden" style={{ background: 'rgba(0,240,255,0.1)' }}><div className="absolute inset-y-0 w-1/2 animate-scan-sweep" style={{ background: 'linear-gradient(90deg, transparent, rgba(0,240,255,0.3), transparent)' }} /></div>
      <div className="px-2 pt-2 pb-1 shrink-0">
        <button onClick={onNewChat} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200" style={{ color: 'var(--primary)', backgroundColor: chatHover ? 'rgba(0,240,255,0.08)' : 'transparent', border: chatHover ? '1px solid rgba(0,240,255,0.2)' : '1px solid transparent' }} onMouseEnter={() => setChatHover(true)} onMouseLeave={() => setChatHover(false)}><Plus size={15} /><span>新建会话</span></button>
      </div>
      <div className="flex-1 overflow-y-auto px-2 pt-1 pb-2" ref={scrollRef}>
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] px-3 mb-2" style={{ color: 'var(--text-muted)' }}>历史会话</p>
        {sessions.length === 0 ? <p className="text-xs text-center py-4" style={{ color: 'var(--text-muted)' }}>暂无会话记录</p> : <div className="space-y-0.5">{sessions.map(s => <SessionItem key={s.id} session={s} isActive={s.id === currentSessionId} onSelect={() => onSelectSession(s.id)} onDelete={() => onDeleteSession(s.id)} />)}</div>}
      </div>
      <div className="px-2 pb-3 pt-1 shrink-0" style={{ borderTop: '1px solid rgba(0,240,255,0.08)' }}><NavItem icon={<Settings size={15} />} label="设置" active={isSettingsPage} onClick={onOpenSettings} /></div>
    </aside>
  );
}
